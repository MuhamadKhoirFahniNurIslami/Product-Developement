<?php
// Tampilkan error jika ada
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi database
$host = '127.0.0.1';      // atau '127.0.0.1'
$user = 'root';           // default user XAMPP
$pass = '';               // kosongkan jika belum pernah diubah
$dbname = 'klinik';    // pastikan database ini sudah ada

// Membuat koneksi
$conn = new mysqli($host, $user, $pass, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("❌ Koneksi gagal: " . $conn->connect_error);
}
?>