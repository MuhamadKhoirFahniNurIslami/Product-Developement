<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Nota</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e9f5ff;
        }

        a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            tr {
                margin-bottom: 15px;
            }

            td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 15px;
                width: 45%;
                padding-left: 15px;
                font-weight: bold;
                text-align: left;
            }

            th {
                display: none;
            }
        }
    </style>
</head>
<body>
<?php include '../config/db.php'; ?>

<h2>Daftar Nota</h2>
<table>
    <thead>
        <tr>
            <th>No Nota</th>
            <th>Pasien</th>
            <th>Dokter</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Detail</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Koneksi database seharusnya sudah dibuat sebelumnya
        $sql = "SELECT nota.nota_id, pasien.nama_pasien, dokter.nama_dokter, nota.tanggal, nota.total_biaya
                FROM nota
                JOIN pasien ON nota.pasien_id = pasien.pasien_id
                JOIN dokter ON nota.dokter_id = dokter.dokter_id";

        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td data-label='No Nota'>{$row['nota_id']}</td>
                    <td data-label='Pasien'>{$row['nama_pasien']}</td>
                    <td data-label='Dokter'>{$row['nama_dokter']}</td>
                    <td data-label='Tanggal'>{$row['tanggal']}</td>
                    <td data-label='Total'>Rp " . number_format($row['total_biaya'], 0, ',', '.') . "</td>
                    <td data-label='Detail'><a href='nota.php?id={$row['nota_id']}'>Lihat Detail</a></td>
                  </tr>";
        }
        ?>
    </tbody>
</table>

</body>
</html>
