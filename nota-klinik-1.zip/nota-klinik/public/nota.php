<?php include '../config/db.php'; ?>

<?php
$nota_id = $_GET['id'];

// Ambil detail nota + item
$sql_detail = "SELECT * FROM detail_nota 
               JOIN item ON detail_nota.item_id = item.item_id 
               WHERE nota_id = '$nota_id'";
$result_detail = $conn->query($sql_detail);

// Ambil info nota + pasien + dokter
$sql_info = "SELECT nota.*, pasien.nama_pasien, pasien.alamat as alamat_pasien, pasien.jenis_kelamin,
                    pasien.umur, pasien.penanggung, dokter.nama_dokter
             FROM nota
             JOIN pasien ON nota.pasien_id = pasien.pasien_id
             JOIN dokter ON nota.dokter_id = dokter.dokter_id
             WHERE nota_id = '$nota_id'";
$nota = $conn->query($sql_info)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Nota <?= $nota_id ?></title>
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 30px;
            background-color: #fff;
            color: #000;
        }

        .header, .footer {
            text-align: center;
            margin-bottom: 10px;
        }

        .header h2 {
            margin: 0;
            font-size: 18px;
        }

        .header .alamat {
            font-size: 14px;
        }

        .line {
            border-top: 2px solid #000;
            margin: 10px 0;
        }

        .info {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }

        .info .left, .info .right {
            width: 48%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 15px;
        }

        table, th, td {
            border: 1px solid #000;
        }

        th, td {
            padding: 6px;
            text-align: center;
            font-size: 14px;
        }

        .signature {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            font-size: 14px;
        }

        .signature div {
            text-align: center;
            width: 40%;
        }

        .total-box {
            text-align: right;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }

        .kembali-link {
            margin-top: 30px;
            display: block;
            text-align: center;
            font-size: 14px;
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>

<div class="header">
    <strong>Dr. Demo Version</strong><br>
    <div class="alamat">Jl. Jambu No. 21 Depok | 776655</div>
</div>

<div class="line"></div>

<div class="info">
    <div class="left">
        Pasien : <?= strtoupper($nota['nama_pasien']) ?><br>
        Alamat : <?= strtoupper($nota['alamat_pasien']) ?><br>
        Penanggung : <?= $nota['penanggung'] ?>
    </div>
    <div class="right">
        Kelamin : <?= $nota['jenis_kelamin'] ?><br>
        Umur : <?= $nota['umur'] ?><br>
        Tanggal : <?= date("d/m/Y", strtotime($nota['tanggal'])) ?>
    </div>
</div>

<div class="line"></div>

<h2 style="text-align: center;">Nota Biaya Periksa / Obat / Tindakan</h2>
<div style="text-align: center;">No. <?= $nota_id ?></div>

<table>
    <tr>
        <th>No.</th>
        <th>Keterangan</th>
        <th>Hrg./Tarif Sat.</th>
        <th>Qty</th>
        <th>SubTotal</th>
    </tr>

    <?php
    $no = 1;
    $total = 0;
    while ($row = $result_detail->fetch_assoc()) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['nama_item']}</td>
                <td>" . number_format($row['harga_satuan'], 0, ',', '.') . "</td>
                <td>{$row['qty']}</td>
                <td>" . number_format($row['subtotal'], 0, ',', '.') . "</td>
              </tr>";
        $total += $row['subtotal'];
        $no++;
    }

    // Tambahkan baris kosong hingga 9
    for ($i = $no; $i <= 9; $i++) {
        echo "<tr>
                <td>$i</td><td>&nbsp;</td><td></td><td></td><td></td>
              </tr>";
    }
    ?>

</table>

<div class="total-box">Total: <?= number_format($total, 0, ',', '.') ?></div>

<div class="signature">
    <div>Pasien<br><br><br><br>_________________</div>
    <div>Dokter<br><br><br><br>_________________</div>
</div>

<a class="kembali-link" href="index.php">Kembali</a>

</body>
</html>
