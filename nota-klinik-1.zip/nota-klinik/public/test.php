<?php
$conn = new mysqli('127.0.0.1', 'root', '', 'db_klinik');

if ($conn->connect_error) {
    die("❌ Koneksi gagal: " . $conn->connect_error);
} else {
    echo "✅ Koneksi database BERHASIL!";
}
?>