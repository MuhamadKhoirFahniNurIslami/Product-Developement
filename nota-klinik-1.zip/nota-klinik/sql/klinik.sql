/*
SQLyog Community v13.3.0 (64 bit)
MySQL - 5.7.33 : Database - klinik
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`klinik` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci */;

USE `klinik`;

/*Table structure for table `detail_nota` */

DROP TABLE IF EXISTS `detail_nota`;

CREATE TABLE `detail_nota` (
  `detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `nota_id` varchar(20) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `harga_satuan` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`detail_id`),
  KEY `nota_id` (`nota_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `detail_nota_ibfk_1` FOREIGN KEY (`nota_id`) REFERENCES `nota` (`nota_id`),
  CONSTRAINT `detail_nota_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `detail_nota` */

insert  into `detail_nota`(`detail_id`,`nota_id`,`item_id`,`qty`,`harga_satuan`,`subtotal`) values 
(1,'N001',1,2,5000.00,10000.00),
(2,'N001',3,1,50000.00,50000.00),
(3,'N002',2,1,8000.00,8000.00),
(4,'N002',4,1,75000.00,75000.00),
(5,'N003',5,1,100000.00,100000.00);

/*Table structure for table `dokter` */

DROP TABLE IF EXISTS `dokter`;

CREATE TABLE `dokter` (
  `dokter_id` int(11) NOT NULL AUTO_INCREMENT,
  `klinik_id` int(11) DEFAULT NULL,
  `nama_dokter` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `spesialisasi` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`dokter_id`),
  KEY `klinik_id` (`klinik_id`),
  CONSTRAINT `dokter_ibfk_1` FOREIGN KEY (`klinik_id`) REFERENCES `klinik` (`klinik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `dokter` */

insert  into `dokter`(`dokter_id`,`klinik_id`,`nama_dokter`,`spesialisasi`) values 
(1,1,'dr. Rina Kusuma','Umum'),
(2,2,'dr. Ahmad Subroto','Anak'),
(3,3,'dr. Dewi Ratnasari','Gigi'),
(4,4,'dr. Bambang Setiawan','Penyakit Dalam'),
(5,5,'dr. Lisa Maharani','Kulit');

/*Table structure for table `item` */

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_item` varchar(50) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `nama_item` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `harga_dasar` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `item` */

insert  into `item`(`item_id`,`kode_item`,`nama_item`,`kategori`,`harga_dasar`) values 
(1,'OBT001','Paracetamol 500mg','Obat',5000.00),
(2,'OBT002','Amoxicillin 500mg','Obat',8000.00),
(3,'SRV001','Pemeriksaan Dokter Umum','Jasa',50000.00),
(4,'SRV002','Pemeriksaan Gigi','Jasa',75000.00),
(5,'SRV003','Tes Darah Lengkap','Jasa',100000.00);

/*Table structure for table `klinik` */

DROP TABLE IF EXISTS `klinik`;

CREATE TABLE `klinik` (
  `klinik_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_klinik` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `kota` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `kode_pos` varchar(10) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `telepon` varchar(15) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`klinik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `klinik` */

insert  into `klinik`(`klinik_id`,`nama_klinik`,`alamat`,`kota`,`kode_pos`,`telepon`) values 
(1,'Klinik Sehat Sentosa','Jl. Merdeka No.1','Jakarta','10110','0211234567'),
(2,'Klinik Harapan Bunda','Jl. Sudirman No.45','Bandung','40210','0227654321'),
(3,'Klinik Mitra Medika','Jl. Diponegoro No.12','Surabaya','60123','0314567890'),
(4,'Klinik Medika Prima','Jl. Gajah Mada No.5','Yogyakarta','55211','0274567890'),
(5,'Klinik Sahabat Sehat','Jl. Ahmad Yani No.99','Semarang','50134','0249876543');

/*Table structure for table `nota` */

DROP TABLE IF EXISTS `nota`;

CREATE TABLE `nota` (
  `nota_id` varchar(20) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `klinik_id` int(11) DEFAULT NULL,
  `pasien_id` int(11) DEFAULT NULL,
  `dokter_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `total_biaya` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`nota_id`),
  KEY `klinik_id` (`klinik_id`),
  KEY `pasien_id` (`pasien_id`),
  KEY `dokter_id` (`dokter_id`),
  CONSTRAINT `nota_ibfk_1` FOREIGN KEY (`klinik_id`) REFERENCES `klinik` (`klinik_id`),
  CONSTRAINT `nota_ibfk_2` FOREIGN KEY (`pasien_id`) REFERENCES `pasien` (`pasien_id`),
  CONSTRAINT `nota_ibfk_3` FOREIGN KEY (`dokter_id`) REFERENCES `dokter` (`dokter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `nota` */

insert  into `nota`(`nota_id`,`klinik_id`,`pasien_id`,`dokter_id`,`tanggal`,`total_biaya`) values 
('N001',1,1,1,'2025-05-01',100000.00),
('N002',2,2,2,'2025-05-02',150000.00),
('N003',3,3,3,'2025-05-03',125000.00),
('N004',4,4,4,'2025-05-04',175000.00),
('N005',5,5,5,'2025-05-05',200000.00);

/*Table structure for table `pasien` */

DROP TABLE IF EXISTS `pasien`;

CREATE TABLE `pasien` (
  `pasien_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pasien` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `jenis_kelamin` char(1) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `umur` int(11) DEFAULT NULL,
  `penanggung` varchar(100) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`pasien_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

/*Data for the table `pasien` */

insert  into `pasien`(`pasien_id`,`nama_pasien`,`alamat`,`jenis_kelamin`,`umur`,`penanggung`) values 
(1,'Andi Wijaya','Jl. Mawar No.3','L',35,'BPJS'),
(2,'Siti Aminah','Jl. Melati No.7','P',28,'Mandiri'),
(3,'Budi Hartono','Jl. Anggrek No.15','L',42,'Asuransi A'),
(4,'Dewi Lestari','Jl. Kenanga No.21','P',30,'BPJS'),
(5,'Rudi Santoso','Jl. Dahlia No.10','L',55,'Mandiri');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
